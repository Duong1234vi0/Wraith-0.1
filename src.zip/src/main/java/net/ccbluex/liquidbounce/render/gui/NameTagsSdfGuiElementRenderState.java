/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2026 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.render.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;

/**
 * Screen-space SDF quad used by the AlphaDLC NameTags background and mask
 * shaders. UV0 carries framebuffer-space location; UV1/UV2 carry fixed-point
 * size/radius so the fragment shader can reproduce AlphaDLC's gl_FragCoord
 * math without per-element uniforms.
 */
public record NameTagsSdfGuiElementRenderState(
    RenderPipeline pipeline,
    TextureSetup textureSetup,
    float x0,
    float y0,
    float x1,
    float y1,
    int argb,
    float locationX,
    float locationY,
    int sizeXFixed,
    int sizeYFixed,
    int radiusFixed,
    Matrix3x2f pose,
    @Nullable ScreenRectangle scissorArea,
    @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {

    @Override
    public void buildVertices(VertexConsumer vertices) {
        vertices.addVertexWith2DPose(pose, x0, y0).setUv(locationX, locationY).setColor(argb)
            .setUv1(sizeXFixed, sizeYFixed).setUv2(radiusFixed, 0);
        vertices.addVertexWith2DPose(pose, x0, y1).setUv(locationX, locationY).setColor(argb)
            .setUv1(sizeXFixed, sizeYFixed).setUv2(radiusFixed, 0);
        vertices.addVertexWith2DPose(pose, x1, y1).setUv(locationX, locationY).setColor(argb)
            .setUv1(sizeXFixed, sizeYFixed).setUv2(radiusFixed, 0);
        vertices.addVertexWith2DPose(pose, x1, y0).setUv(locationX, locationY).setColor(argb)
            .setUv1(sizeXFixed, sizeYFixed).setUv2(radiusFixed, 0);
    }
}
