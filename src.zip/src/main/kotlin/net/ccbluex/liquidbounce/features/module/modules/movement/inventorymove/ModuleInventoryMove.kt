/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2025 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.inventorymove
import net.ccbluex.liquidbounce.utils.entity.*

import net.ccbluex.liquidbounce.config.types.NamedChoice
import net.ccbluex.liquidbounce.event.events.GameTickEvent
import net.ccbluex.liquidbounce.event.events.KeyboardKeyEvent
import net.ccbluex.liquidbounce.event.events.MovementInputEvent
import net.ccbluex.liquidbounce.event.events.PacketEvent
import net.ccbluex.liquidbounce.event.events.SprintEvent
import net.ccbluex.liquidbounce.event.handler
import net.ccbluex.liquidbounce.features.module.Category
import net.ccbluex.liquidbounce.features.module.ClientModule
import net.ccbluex.liquidbounce.features.module.modules.movement.inventorymove.features.InventoryMoveBlinkFeature
import net.ccbluex.liquidbounce.features.module.modules.movement.inventorymove.features.InventoryMoveSneakControlFeature
import net.ccbluex.liquidbounce.features.module.modules.movement.inventorymove.features.InventoryMoveSprintControlFeature
import net.ccbluex.liquidbounce.features.module.modules.movement.inventorymove.features.InventoryMoveTimerFeature
import net.ccbluex.liquidbounce.utils.client.sendPacketSilently
import net.ccbluex.liquidbounce.utils.entity.any
import net.ccbluex.liquidbounce.utils.inventory.InventoryManager
import net.ccbluex.liquidbounce.utils.inventory.closeInventorySilently
import net.ccbluex.liquidbounce.utils.inventory.isInInventoryScreen
import net.ccbluex.liquidbounce.utils.kotlin.EventPriorityConvention.FINAL_DECISION
import net.ccbluex.liquidbounce.utils.kotlin.EventPriorityConvention.FIRST_PRIORITY
import net.ccbluex.liquidbounce.utils.movement.DirectionalInput
import net.minecraft.client.gui.screens.ChatScreen
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
import net.minecraft.client.gui.screens.inventory.InventoryScreen
import net.minecraft.client.KeyMapping
import net.minecraft.world.item.CreativeModeTabs
import net.minecraft.network.protocol.Packet
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket
import net.minecraft.network.protocol.game.ServerboundContainerSlotStateChangedPacket
import org.lwjgl.glfw.GLFW

/**
 * InventoryMove module
 *
 * Allows you to walk while an inventory is opened.
 */

object ModuleInventoryMove : ClientModule("InventoryMove", Category.MOVEMENT) {

    private val behavior by enumChoice("Behavior", Behaviour.NORMAL)

    @Suppress("unused")
    enum class Behaviour(override val choiceName: String) : NamedChoice {
        NORMAL("Normal"),
        SAFE("Safe"), // disable clicks while moving
        UNDETECTABLE("Undetectable"), // stop in inventory
        STOP_ON_ACTION("StopOnAction"), // stop input on inventory action
    }

    private val passthroughSneak by boolean("PassthroughSneak", false)

    // states of movement keys, using mc.options.<key>.isPressed doesn't work for some reason
    private val movementKeys = mc.options.run {
        arrayOf(forwardKey, leftKey, backKey, rightKey, jumpKey, sneakKey).associateWith { false }.toMutableMap()
    }

    /**
     * Restricts user from clicking while moving in inventory.
     */
    val doNotAllowClicking
        get() = behavior == Behaviour.SAFE && movementKeys.any { (key, pressed) ->
            pressed && shouldHandleInputs(key)
        }

    init {
        tree(InventoryMoveSprintControlFeature)
        tree(InventoryMoveSneakControlFeature)
        tree(InventoryMoveTimerFeature)
        tree(InventoryMoveBlinkFeature)
    }

    fun shouldHandleInputs(keyBinding: KeyMapping): Boolean {
        val screen = mc.screen ?: return true

        if (!running || screen is ChatScreen || isInCreativeSearchField()) {
            return false
        }

        if (keyBinding == mc.options.sneakKey && !passthroughSneak) {
            return false
        }

        // If we are in a handled screen, we should handle the inputs only if the undetectable option is not enabled
        return behavior == Behaviour.NORMAL || screen !is AbstractContainerScreen<*>
            || behavior == Behaviour.SAFE && screen is InventoryScreen
            || behavior == Behaviour.STOP_ON_ACTION
    }

    private val delayedContainerPackets = mutableListOf<Packet<*>>()

    @Volatile private var stopOnActionPending = false
    @Volatile private var pendingFlushTicks = 0

    override fun disable() {
        delayedContainerPackets.clear()
        stopOnActionPending = false
        pendingFlushTicks = 0
    }

    @Suppress("unused")
    private val movementInputHandler = handler<MovementInputEvent>(priority = FINAL_DECISION) { event ->
        if (behavior != Behaviour.STOP_ON_ACTION || delayedContainerPackets.isEmpty()) {
            return@handler
        }

        event.sneak = false
        event.jump = false
        event.directionalInput = DirectionalInput.NONE

        // Set the pending flag so sprintSuppressHandler forces sprint=false on the
        // SprintEvent that fires later in this same modifyInput call. The combined
        // effect: vanilla constructs Input(no movement, no sprint) → aiStep calls
        // setSprinting(false) → LocalPlayer.tick sends PLAYER_INPUT(empty) and
        // STOP_SPRINTING this tick. Click is held one more tick so those packets
        // hit the wire BEFORE the click.
        stopOnActionPending = true
        pendingFlushTicks = 1
    }

    @Suppress("unused")
    private val sprintSuppressHandler = handler<SprintEvent>(priority = FINAL_DECISION) { event ->
        if (stopOnActionPending && event.source == SprintEvent.Source.INPUT) {
            event.sprint = false
        }
    }

    @Suppress("unused")
    private val tickFlushHandler = handler<GameTickEvent> {
        if (pendingFlushTicks <= 0) {
            return@handler
        }

        pendingFlushTicks--
        if (pendingFlushTicks > 0) {
            return@handler
        }

        if (delayedContainerPackets.isNotEmpty()) {
            val snapshot = delayedContainerPackets.toTypedArray()
            delayedContainerPackets.clear()
            snapshot.forEach(::sendPacketSilently)
        }
        stopOnActionPending = false
    }

    @Suppress("unused")
    private val packetHandler = handler<PacketEvent>(priority = FIRST_PRIORITY) { event ->
        if (behavior != Behaviour.STOP_ON_ACTION) {
            return@handler
        }

        val packet = event.packet

        if (packet.isC2SContainerPacket() && player.input.playerInput.any) {
            event.cancelEvent()
            delayedContainerPackets += packet
        }
    }

    @Suppress("unused")
    private val keyHandler = handler<KeyboardKeyEvent> { event ->
        val key = movementKeys.keys.find { it.matchesKey(event.keyCode, event.scanCode) }
            ?: return@handler
        val pressed = shouldHandleInputs(key) && event.action != GLFW.GLFW_RELEASE
        movementKeys[key] = pressed

        if (behavior == Behaviour.SAFE && isInInventoryScreen && InventoryManager.isInventoryOpenServerSide
            && pressed) {
            closeInventorySilently()
        }
    }

    /**
     * Checks if the player is in the creative search field
     */
    private fun isInCreativeSearchField() =
        mc.screen is CreativeModeInventoryScreen &&
            CreativeModeInventoryScreen.selectedTab == CreativeModeTabs.searchTab()

    private fun Packet<*>.isC2SContainerPacket() = when (this) {
        is ServerboundContainerClickPacket,
        is ServerboundContainerButtonClickPacket,
        is ServerboundSetCreativeModeSlotPacket,
        is ServerboundContainerSlotStateChangedPacket,
        is ServerboundContainerClosePacket -> true

        else -> false
    }

}
