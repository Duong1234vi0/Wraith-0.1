/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2025 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 *
 *
 */

package net.ccbluex.liquidbounce.features.module.modules.movement.fly.modes
import net.ccbluex.liquidbounce.utils.entity.*

import net.ccbluex.liquidbounce.config.types.nesting.Choice
import net.ccbluex.liquidbounce.config.types.nesting.ChoiceConfigurable
import net.ccbluex.liquidbounce.event.events.PacketEvent
import net.ccbluex.liquidbounce.event.events.TransferOrigin
import net.ccbluex.liquidbounce.event.handler
import net.ccbluex.liquidbounce.event.tickHandler
import net.ccbluex.liquidbounce.features.module.modules.movement.fly.ModuleFly
import net.ccbluex.liquidbounce.utils.aiming.RotationManager
import net.ccbluex.liquidbounce.utils.aiming.RotationsConfigurable
import net.ccbluex.liquidbounce.utils.aiming.data.Rotation
import net.ccbluex.liquidbounce.utils.block.isBlockAtPosition
import net.ccbluex.liquidbounce.utils.entity.box
import net.ccbluex.liquidbounce.utils.entity.withStrafe
import net.ccbluex.liquidbounce.utils.inventory.Slots
import net.ccbluex.liquidbounce.utils.kotlin.Priority
import net.ccbluex.liquidbounce.utils.kotlin.random
import net.ccbluex.liquidbounce.utils.math.copy
import net.minecraft.world.level.block.Block
import net.minecraft.world.item.Items
import net.minecraft.network.protocol.game.ServerboundUseItemPacket
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket
import net.minecraft.world.InteractionHand

internal object FlyEnderpearl : Choice("Enderpearl") {

    override val parent: ChoiceConfigurable<*>
        get() = ModuleFly.modes

    val speed by float("Speed", 1f, 0.5f..2f)

    var threwPearl = false
    var canFly = false

    val rotations = tree(RotationsConfigurable(this))

    override fun enable() {
        threwPearl = false
        canFly = false
    }

    val repeatable = tickHandler {
        val slot = Slots.Hotbar.findSlot(Items.ENDER_PEARL)?.hotbarSlot

        if (player.isDead || player.isSpectator || player.abilities.creativeMode) {
            return@tickHandler
        }

        if (!threwPearl && !canFly) {
            if (slot != null) {
                if (slot != player.inventory.selectedSlot) {
                    network.sendPacket(ServerboundSetCarriedItemPacket(slot))
                }

                if (player.pitch <= 80) {
                    RotationManager.setRotationTarget(
                        Rotation(player.yaw, (80f..90f).random()),
                        configurable = rotations,
                        provider = ModuleFly,
                        priority = Priority.IMPORTANT_FOR_USAGE_2
                    )
                }

                waitTicks(2)
                interaction.sendSequencedPacket(world) { sequence ->
                    ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, player.yaw, player.pitch)
                }

                if (slot != player.inventory.selectedSlot) {
                    network.sendPacket(ServerboundSetCarriedItemPacket(player.inventory.selectedSlot))
                }

                threwPearl = true
            }
        } else if (!threwPearl && canFly) {
            player.deltaMovement = player.deltaMovement.withStrafe(speed = speed.toDouble())
            player.deltaMovement = player.deltaMovement.copy(y = when {
                mc.options.jumpKey.isPressed -> speed.toDouble()
                mc.options.sneakKey.isPressed -> -speed.toDouble()
                else -> 0.0
            })
            return@tickHandler
        }
    }

    val packetHandler = handler<PacketEvent> { event ->
        if (event.origin == TransferOrigin.OUTGOING && event.packet is ServerboundAcceptTeleportationPacket
            && isABitAboveGround() && threwPearl) {
            threwPearl = false
            canFly = true
        }
    }

    fun isABitAboveGround(): Boolean {
        for (y in 0..5) {
            val boundingBox = player.box
            val detectionBox = boundingBox.withMinY(boundingBox.minY - y)

            return detectionBox.isBlockAtPosition { it is Block }
        }
        return false
    }
}
