/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2025 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.features.module.modules.player.offhand

import com.google.common.base.Predicate
import net.ccbluex.liquidbounce.config.types.NamedChoice
import net.ccbluex.liquidbounce.config.types.nesting.ToggleableConfigurable
import net.ccbluex.liquidbounce.event.EventManager
import net.ccbluex.liquidbounce.event.events.KeyEvent
import net.ccbluex.liquidbounce.event.events.PacketEvent
import net.ccbluex.liquidbounce.event.events.RefreshArrayListEvent
import net.ccbluex.liquidbounce.event.events.ScheduleInventoryActionEvent
import net.ccbluex.liquidbounce.event.events.TransferOrigin
import net.ccbluex.liquidbounce.event.handler
import net.ccbluex.liquidbounce.features.module.Category
import net.ccbluex.liquidbounce.features.module.ClientModule
import net.ccbluex.liquidbounce.features.module.modules.combat.killaura.ModuleKillAura
import net.ccbluex.liquidbounce.utils.entity.*
import net.ccbluex.liquidbounce.utils.inventory.HotbarItemSlot
import net.ccbluex.liquidbounce.utils.inventory.ItemSlot
import net.ccbluex.liquidbounce.utils.inventory.OffHandSlot
import net.ccbluex.liquidbounce.utils.item.isSword
import net.ccbluex.liquidbounce.utils.client.Chronometer
import net.ccbluex.liquidbounce.utils.client.isNewerThanOrEquals1_16
import net.ccbluex.liquidbounce.utils.client.usesViaFabricPlus
import net.ccbluex.liquidbounce.utils.inventory.*
import net.minecraft.core.component.DataComponents
import net.minecraft.world.item.alchemy.PotionContents
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import org.lwjgl.glfw.GLFW

/**
 * Offhand module
 *
 * Manages your offhand.
 */
object ModuleOffhand : ClientModule("Offhand", Category.PLAYER, aliases = arrayOf("AutoTotem")) {

    private val inventoryConstraints = PlayerInventoryConstraints(
        name = "OffhandInternal",
        defaultStartDelay = 0..0,
        defaultClickDelay = 0..0,
        defaultCloseDelay = 0..0
    )
    private var switchMode = enumChoice(
        "SwitchMode",
        if (usesViaFabricPlus) SwitchMode.AUTOMATIC else SwitchMode.SWITCH
    )
    private val cycleSlots by key("Cycle", GLFW.GLFW_KEY_H)

    private object Gapple : ToggleableConfigurable(this, "Gapple", true) {
        val gappleBind by key("GappleBind")
    }

    private object Crystal : ToggleableConfigurable(this, "Crystal", true) {
        val whenNoTotems by boolean("WhenNoTotems", true)
        val crystalBind by key("CrystalBind")
    }

    private object Strength : ToggleableConfigurable(this, "StrengthPotion", false) {
        val strengthBind by key("StrengthBind")
    }

    init {
        treeAll(
            Totem,
            Crystal,
            Gapple,
            Strength
        )
    }

    private val INVENTORY_MAIN_PRIORITY = Slots.Inventory + Slots.Hotbar
    private val INVENTORY_HOTBAR_PRIORITY = Slots.Hotbar + Slots.Inventory
    private val chronometer = Chronometer()
    private var activeMode: Mode = Mode.NONE
    private var lastMode: Mode? = null
    private var lastTagMode: Mode = Mode.NONE
    private var staticMode = Mode.NONE
    private var last: Pair<Item, ItemSlot>? = null
    private var guardedTotemSwap: GuardedTotemSwap? = null

    override val tag: String
        get() = activeMode.modeName

    override fun enable() {
        staticMode = when {
            Crystal.enabled && Mode.CRYSTAL.canCycleTo() -> Mode.CRYSTAL
            Gapple.enabled -> Mode.GAPPLE
            Totem.enabled && !Totem.Health.enabled -> Mode.TOTEM
            else -> Mode.NONE
        }
    }

    @Suppress("unused")
    val keyHandler = handler<KeyEvent> {
        if (it.action != GLFW.GLFW_PRESS) {
            return@handler
        }

        when (it.key.value) {
            Gapple.gappleBind.value -> Mode.GAPPLE.onBindPress()
            Crystal.crystalBind.value -> Mode.CRYSTAL.onBindPress()
            Strength.strengthBind.value -> {
                // since we can't cycle to strength, its status has to be checked here
                if (Strength.enabled) {
                    Mode.STRENGTH.onBindPress()
                }
            }

            cycleSlots.value -> {
                val entries = Mode.entries
                val startIndex = staticMode.ordinal
                var index = (startIndex + 1) % entries.size

                while (index != startIndex) {
                    val mode = entries[index]
                    if (mode.canCycleTo()) {
                        staticMode = mode
                        return@handler
                    }

                    index = (index + 1) % entries.size
                }
            }
        }
    }

    @Suppress("unused")
    private val packetHandler = handler<PacketEvent> { event ->
        if (event.origin != TransferOrigin.INCOMING) {
            return@handler
        }

        val packet = event.packet as? ClientboundEntityEventPacket ?: return@handler
        if (packet.eventId.toInt() == TOTEM_USE_STATUS && packet.getEntity(world) == player) {
            Totem.TotemGuard.markPop()
        }
    }

    @Suppress("unused")
    private val autoTotemHandler = handler<ScheduleInventoryActionEvent>(priority = 100) {
        activeMode = Mode.entries.firstOrNull(Mode::shouldEquip) ?: staticMode
        if (activeMode == Mode.NONE && Totem.Health.switchBack && lastMode == Mode.TOTEM) {
            activeMode = Mode.BACK
        }

        if (activeMode != lastTagMode) {
            EventManager.callEvent(RefreshArrayListEvent)
            lastTagMode = activeMode
        }

        if (activeMode != lastMode && lastMode == Mode.TOTEM) {
            if (!Totem.switchBackStarted) {
                Totem.switchBack.reset()
            }

            Totem.switchBackStarted = true
            if (!Totem.switchBack.hasElapsed(Totem.switchBackDelay.toLong())) {
                return@handler
            }
        }

        Totem.switchBackStarted = false

        if (continueGuardedTotemRefill(it)) {
            return@handler
        }

        if (!chronometer.hasElapsed(activeMode.getDelay().toLong())) {
            return@handler
        }

        val slot = activeMode.getSlot() ?: return@handler
        lastMode = activeMode

        // the item is already located in Off-hand slot
        if (slot == OffHandSlot) {
            return@handler
        }

        if (Totem.Health.switchBack) {
            last = slot.itemStack.item to slot
        }

        val guardedTotemRefill = activeMode == Mode.TOTEM && Totem.TotemGuard.shouldUseGuardedTiming()
        if (guardedTotemRefill) {
            startGuardedTotemRefill(it, slot)
            return@handler
        }

        val actions = switchMode.get().performSwitch(slot)
        if (actions.isEmpty()) {
            chronometer.reset()
            return@handler
        }

        if (activeMode != Mode.TOTEM || !Totem.send(actions)) {
            it.schedule(inventoryConstraints, actions)
        }

        chronometer.reset()
    }

    private fun startGuardedTotemRefill(event: ScheduleInventoryActionEvent, from: ItemSlot) {
        val returnSlot = if (!OffHandSlot.itemStack.isEmpty) {
            from
        } else {
            null
        }

        val delayTicks = Totem.TotemGuard.nextPickDelayTicks()
        guardedTotemSwap = GuardedTotemSwap(
            stage = GuardedTotemStage.PICK_TOTEM,
            sourceSlot = from,
            returnSlot = returnSlot,
            delayTicks = delayTicks,
            lastTick = player.age
        )

        InventoryManager.holdInventoryOpenFor(delayTicks + 7)
        if (delayTicks <= 0) {
            event.schedule(Totem.TotemGuard.constraints, ClickInventoryAction.performPickup(slot = from))
            guardedTotemSwap?.stage = GuardedTotemStage.PLACE_OFFHAND
            guardedTotemSwap?.delayTicks = Totem.TotemGuard.nextPlaceDelayTicks()
        }
        Totem.TotemGuard.markScheduled()
        chronometer.reset()
    }

    private fun continueGuardedTotemRefill(event: ScheduleInventoryActionEvent): Boolean {
        val state = guardedTotemSwap ?: return false

        if (OffHandSlot.itemStack.item == Items.TOTEM_OF_UNDYING) {
            guardedTotemSwap = null
            InventoryManager.releaseInventoryOpenHold()
            return false
        }

        val currentTick = player.age
        if (state.lastTick != currentTick) {
            state.lastTick = currentTick
            if (state.delayTicks > 0) {
                state.delayTicks--
            }
        }

        if (state.delayTicks > 0) {
            InventoryManager.holdInventoryOpenFor(2)
            return true
        }

        when (state.stage) {
            GuardedTotemStage.PICK_TOTEM -> {
                event.schedule(Totem.TotemGuard.constraints, ClickInventoryAction.performPickup(slot = state.sourceSlot))
                state.stage = GuardedTotemStage.PLACE_OFFHAND
                state.delayTicks = Totem.TotemGuard.nextPlaceDelayTicks()
                state.lastTick = currentTick
                InventoryManager.holdInventoryOpenFor(state.delayTicks + 3)
            }

            GuardedTotemStage.PLACE_OFFHAND -> {
                val returnSlot = state.returnSlot
                if (returnSlot != null) {
                    event.schedule(Totem.TotemGuard.constraints, ClickInventoryAction.performPickup(slot = OffHandSlot))
                    state.stage = GuardedTotemStage.RETURN_CURSOR
                    state.delayTicks = Totem.TotemGuard.nextReturnDelayTicks()
                    state.lastTick = currentTick
                    InventoryManager.holdInventoryOpenFor(state.delayTicks + 2)
                } else {
                    InventoryManager.releaseInventoryOpenHold()
                    event.schedule(
                        Totem.TotemGuard.constraints,
                        ClickInventoryAction.performPickup(slot = OffHandSlot),
                        CloseInventorySilentlyAction
                    )
                    guardedTotemSwap = null
                }
            }

            GuardedTotemStage.RETURN_CURSOR -> {
                InventoryManager.releaseInventoryOpenHold()
                event.schedule(
                    Totem.TotemGuard.constraints,
                    ClickInventoryAction.performPickup(slot = state.returnSlot ?: return false),
                    CloseInventorySilentlyAction
                )
                guardedTotemSwap = null
            }
        }

        chronometer.reset()
        return true
    }

    fun performSwitch(from: ItemSlot, smart: Boolean): List<ClickInventoryAction> {
        val actions = ArrayList<ClickInventoryAction>(3)

        if (smart && from is HotbarItemSlot) {
            val selectedSlot = player.inventory.selectedSlot
            val targetSlot = from.hotbarSlot
            if (selectedSlot != targetSlot) {
                network.sendPacket(ServerboundSetCarriedItemPacket(targetSlot))
            }
            network.sendPacket(
                ServerboundPlayerActionPacket(
                    ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                    BlockPos.ZERO,
                    Direction.DOWN
                )
            )
            if (selectedSlot != targetSlot) {
                network.sendPacket(ServerboundSetCarriedItemPacket(selectedSlot))
            }
        } else {
            actions += ClickInventoryAction.performPickup(slot = from)
            actions += ClickInventoryAction.performPickup(slot = OffHandSlot)
            if (!OffHandSlot.itemStack.isEmpty) {
                actions += ClickInventoryAction.performPickup(slot = from)
            }
        }

        return actions
    }

    fun isOperating() = running && activeMode != Mode.NONE

    private data class GuardedTotemSwap(
        var stage: GuardedTotemStage,
        val sourceSlot: ItemSlot,
        val returnSlot: ItemSlot?,
        var delayTicks: Int,
        var lastTick: Int
    )

    private enum class GuardedTotemStage {
        PICK_TOTEM,
        PLACE_OFFHAND,
        RETURN_CURSOR
    }

    private enum class Mode(val modeName: String, private val item: Item, private val fallBackItem: Item? = null) {
        TOTEM("Totem", Items.TOTEM_OF_UNDYING) {
            override fun shouldEquip() = Totem.shouldEquip()

            override fun getDelay() = Totem.switchDelay

            override fun getPrioritizedInventoryPart() = 1

            override fun getSlot(): ItemSlot? {
                val slot = super.getSlot()
                if (slot == null && Crystal.enabled && Crystal.whenNoTotems) {
                    return CRYSTAL.getSlot()
                }

                return slot
            }

            override fun canCycleTo() = Totem.enabled
        },
        STRENGTH("Strength", Items.POTION) {
            val isStrengthPotion = Predicate<ItemStack> { stack ->
                if (stack.item != Items.POTION) {
                    return@Predicate false
                }

                val content = stack.getOrDefault(DataComponents.POTION_CONTENTS, PotionContents.EMPTY)
                return@Predicate content.effects.any { effect -> effect.effectType == MobEffects.STRENGTH }
            }

            override fun shouldEquip(): Boolean {
                if (!Strength.enabled || !ModuleKillAura.running || player.hasStatusEffect(MobEffects.STRENGTH)) {
                    return false
                }

                return player.mainHandItem.isSword
            }

            override fun getSlot(): ItemSlot? {
                if (isStrengthPotion.test(player.offhandItem)) {
                    return OffHandSlot
                }

                return INVENTORY_MAIN_PRIORITY.findSlot { isStrengthPotion.test(it) }
            }
        },
        GAPPLE("Gapple", Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE) {
            override fun shouldEquip(): Boolean {
                if (!Gapple.enabled) {
                    return false
                }

                return player.mainHandItem.isSword
            }

            override fun canCycleTo() = Gapple.enabled
        },
        CRYSTAL("Crystal", Items.END_CRYSTAL) {
            override fun canCycleTo() = Crystal.enabled
        },
        BACK("Back", Items.AIR) {
            override fun getSlot(): ItemSlot? {
                return last?.let {
                    if (it.first == it.second.itemStack.item) it.second else null
                }
            }
        },
        NONE("None", Items.AIR);

        private var modeBeforeDirectSwitch: Mode? = null

        open fun shouldEquip() = false

        open fun getDelay() = 0

        open fun canCycleTo() = false

        /**
         * 0 = Main inventory
         * 1 = Hotbar
         */
        open fun getPrioritizedInventoryPart() = 0

        fun onBindPress() {
            if (activeMode == this && modeBeforeDirectSwitch != null && modeBeforeDirectSwitch!!.canCycleTo()) {
                staticMode = modeBeforeDirectSwitch!!
                modeBeforeDirectSwitch = null
            } else if (canCycleTo()) {
                modeBeforeDirectSwitch = staticMode
                staticMode = this
            } else {
                modeBeforeDirectSwitch = null
            }
        }

        open fun getSlot(): ItemSlot? {
            if (item == Items.AIR) {
                return null
            }

            if (player.offhandItem.item == item) {
                return OffHandSlot
            }

            val slots = if (getPrioritizedInventoryPart() == 0) {
                INVENTORY_MAIN_PRIORITY
            } else {
                INVENTORY_HOTBAR_PRIORITY
            }

            var itemSlot = slots.findSlot(item)
            if (itemSlot == null && fallBackItem != null) {
                if (player.offhandItem.item == fallBackItem) {
                    return OffHandSlot
                }

                itemSlot = slots.findSlot(fallBackItem)
            }

            return itemSlot
        }
    }

    @Suppress("unused")
    private enum class SwitchMode(override val choiceName: String) : NamedChoice {
        /**
         * Pickup, but it performs a SWAP_ITEM_WITH_OFFHAND action whenever possible to possible send fewer packets.
         * Works on all versions.
         *
         * It's not the default because some servers kick you when you perform a SWAP_ITEM_WITH_OFFHAND action
         * often and quickly.
         */
        SMART("Smart") {
            override fun performSwitch(from: ItemSlot) = performSwitch(from, true)
        },

        /**
         * Performs a switch action, works on 1.16.
         * The best method on newer servers.
         */
        SWITCH("Switch") {
            override fun performSwitch(from: ItemSlot) = listOf(
                ClickInventoryAction.performSwap(
                    from = from,
                    to = OffHandSlot
                )
            )
        },

        /**
         * Performs 2-3 a pickup actions.
         * Works on all versions.
         */
        PICKUP("PickUp") {
            override fun performSwitch(from: ItemSlot) = performSwitch(from, false)
        },

        /**
         * Chooses the switch action based on the version. Only works if vfp is installed.
         */
        AUTOMATIC("Automatic") {
            override fun performSwitch(from: ItemSlot): List<ClickInventoryAction> {
                return if (isNewerThanOrEquals1_16) {
                    SWITCH.performSwitch(from)
                } else {
                    PICKUP.performSwitch(from)
                }
            }
        };

        abstract fun performSwitch(from: ItemSlot): List<ClickInventoryAction>
    }

    private const val TOTEM_USE_STATUS = 35

}
