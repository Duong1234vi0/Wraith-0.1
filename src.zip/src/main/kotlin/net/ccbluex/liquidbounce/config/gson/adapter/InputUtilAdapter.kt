/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 202 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.config.gson.adapter
import net.ccbluex.liquidbounce.utils.entity.*

import com.google.gson.*
import com.mojang.blaze3d.platform.InputConstants
import java.lang.reflect.Type

object InputUtilAdapter : JsonSerializer<InputConstants.Key>, JsonDeserializer<InputConstants.Key> {

    override fun serialize(src: InputConstants.Key, typeOfSrc: Type, context: JsonSerializationContext) =
        JsonPrimitive(src.name)

    override fun deserialize(json: JsonElement, typeOfT: Type?, context: JsonDeserializationContext?): InputConstants.Key =
        InputConstants.getKey(json.asString)

}
