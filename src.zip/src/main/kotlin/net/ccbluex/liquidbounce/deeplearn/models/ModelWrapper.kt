/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2025 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.deeplearn.models
import net.ccbluex.liquidbounce.utils.entity.*

import ai.djl.Model
import ai.djl.inference.Predictor
import ai.djl.ndarray.NDManager
import ai.djl.ndarray.types.Shape
import ai.djl.nn.Activation
import ai.djl.nn.Blocks
import ai.djl.nn.SequentialBlock
import ai.djl.nn.core.Linear
import ai.djl.nn.norm.BatchNorm
import ai.djl.training.DefaultTrainingConfig
import ai.djl.training.EasyTrain
import ai.djl.training.dataset.ArrayDataset
import ai.djl.training.initializer.XavierInitializer
import ai.djl.training.listener.LoggingTrainingListener
import ai.djl.training.loss.Loss
import ai.djl.training.optimizer.Adam
import ai.djl.training.tracker.Tracker
import ai.djl.translate.TranslateException
import ai.djl.translate.Translator
import net.ccbluex.liquidbounce.config.types.nesting.Choice
import net.ccbluex.liquidbounce.config.types.nesting.ChoiceConfigurable
import net.ccbluex.liquidbounce.deeplearn.DeepLearningEngine
import net.ccbluex.liquidbounce.deeplearn.DeepLearningEngine.modelsFolder
import net.ccbluex.liquidbounce.deeplearn.listener.OverlayTrainingListener
import net.ccbluex.liquidbounce.utils.client.logger
import java.io.ByteArrayInputStream
import java.io.Closeable
import java.io.InputStream
import java.nio.file.Path
import java.util.*

private const val NUM_EPOCH = 100
private const val BATCH_SIZE = 32

abstract class ModelWrapper<I, O>(
    name: String,
    val translator: Translator<I, O>,
    val outputs: Long,
    override val parent: ChoiceConfigurable<*>
) : Choice(name), Closeable {

    private val modelDelegate = lazy {
        Model.newInstance(name).apply {
            block = createMlpBlock(outputs)
        }
    }
    private val model: Model by modelDelegate
    private var predictor: Predictor<I, O>? = null
    private var manualMlpModel: ManualMlpModel? = null

    private fun predictor(): Predictor<I, O> {
        return predictor ?: model.newPredictor(translator).also {
            predictor = it
        }
    }

    @Throws(TranslateException::class)
    fun predict(input: I): O {
        require(DeepLearningEngine.isInitialized) { "DeepLearningEngine is not initialized" }

        @Suppress("UNCHECKED_CAST")
        manualMlpModel?.let { fallback ->
            if (input is FloatArray) {
                return fallback.predict(input) as O
            }
        }

        return predictor().predict(input)
    }

    fun train(features: Array<FloatArray>, labels: Array<FloatArray>) {
        require(DeepLearningEngine.isInitialized) { "DeepLearningEngine is not initialized" }

        require(features.size == labels.size) { "Features and labels must have the same size" }
        require(features.isNotEmpty()) { "Features and labels must not be empty" }
        val inputs = features[0].size.toLong()

        try {
            val trainingConfig = DefaultTrainingConfig(Loss.l2Loss())
                .optInitializer(XavierInitializer(), "weight")
                .optOptimizer(
                    Adam.builder()
                        .optLearningRateTracker(Tracker.fixed(0.001f))
                        .build()
                )
                .addTrainingListeners(LoggingTrainingListener(), OverlayTrainingListener(NUM_EPOCH))
            val trainer = model.newTrainer(trainingConfig)

            val manager = NDManager.newBaseManager()
            val trainingSet = ArrayDataset.Builder()
                .setData(manager.create(features))
                .optLabels(manager.create(labels))
                .setSampling(BATCH_SIZE, true)
                .build()
            trainer.initialize(Shape(BATCH_SIZE.toLong(), inputs))

            EasyTrain.fit(trainer, NUM_EPOCH, trainingSet, null)
            manualMlpModel = null
        } catch (error: Throwable) {
            if (!error.isUnsupportedBackendOperation()) {
                throw error
            }

            logger.info("[DeepLearning] Backend does not support training; falling back to mobile CPU trainer.")
            manualMlpModel = ManualMlpModel.train(features, labels, outputs)
        }
    }

    fun load(stream: InputStream) {
        val bytes = stream.readBytes()

        runCatching {
            manualMlpModel = null
            model.load(ByteArrayInputStream(bytes))
        }.onFailure { error ->
            if (error !is UnsupportedOperationException) {
                throw error
            }

            manualMlpModel = ManualMlpModel.fromDjlParams(bytes)
            logger.info("[DeepLearning] Loaded model '$name' through manual MLP fallback.")
        }
    }

    fun load(path: Path) {
        runCatching {
            manualMlpModel = null
            model.load(path, "tf")
        }.onFailure { error ->
            if (error !is UnsupportedOperationException) {
                throw error
            }

            val paramsFile = path.toFile()
                .walkTopDown()
                .firstOrNull { it.isFile && it.extension == "params" }
                ?: throw error

            paramsFile.inputStream().use(::load)
        }
    }

    fun load(name: String = this.name) {
        val folder = modelsFolder.resolve(name)

        if (folder.exists()) {
            load(folder.toPath())
        } else {
            val lowercaseName = name.lowercase(Locale.ENGLISH)
            javaClass.getResourceAsStream("/resources/liquidbounce/models/${lowercaseName}.params")!!.use { stream ->
                load(stream)
            }
        }
    }

    fun save(path: Path) {
        manualMlpModel?.let { manualModel ->
            val folder = path.toFile().apply { mkdirs() }
            folder.resolve("$name.params").writeBytes(manualModel.toDjlParams())
            logger.info("[DeepLearning] Saved model '$name' through manual MLP fallback.")
            return
        }

        model.save(path, "tf")
    }

    fun save(name: String = this.name) {
        save(modelsFolder.resolve(name).toPath())
    }

    fun delete() {
        close()
        modelsFolder.resolve(name).delete()
    }

    override fun close() {
        predictor?.close()

        if (modelDelegate.isInitialized()) {
            model.close()
        }
    }

}

private fun Throwable.isUnsupportedBackendOperation(): Boolean {
    var current: Throwable? = this

    while (current != null) {
        if (current is UnsupportedOperationException ||
            current.message?.contains("Not supported", ignoreCase = true) == true) {
            return true
        }

        current = current.cause
    }

    return false
}

/**
 * Create a block for the model. This is a simple Multi-Layer Perceptron (MLP) model.
 */
private fun createMlpBlock(outputs: Long) = SequentialBlock()
    .add(Linear.builder()
        .setUnits(128)
        .build())
    .add(Blocks.batchFlattenBlock())
    .add(BatchNorm.builder().build())
    .add(Activation.reluBlock())

    .add(Linear.builder()
        .setUnits(64)
        .build())
    .add(Blocks.batchFlattenBlock())
    .add(BatchNorm.builder().build())
    .add(Activation.reluBlock())

    .add(Linear.builder()
        .setUnits(32)
        .build())
    .add(Blocks.batchFlattenBlock())
    .add(BatchNorm.builder().build())
    .add(Activation.reluBlock())

    .add(Linear.builder()
        .setUnits(outputs)
        .build())
